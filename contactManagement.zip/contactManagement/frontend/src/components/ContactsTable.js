import React, { useState } from "react";
import './ContactTable.css';
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    TextField,
    useMediaQuery,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";

const ContactsTable = ({ contacts, onEdit, onDelete }) => {
    const [open, setOpen] = useState(false);
    const [currentContact, setCurrentContact] = useState({});
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

    const handleOpen = (contact) => {
        setCurrentContact(contact);
        setOpen(true);
    };

    const handleClose = () => setOpen(false);

    const handleSave = () => {
        onEdit(currentContact);
        handleClose();
    };

    const handleChange = (e) => {
        setCurrentContact({ ...currentContact, [e.target.name]: e.target.value });
    };

    return (
        <>
            <div className="table-container" style={{marginTop:"15px"}}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell style={{ color: 'blue', fontWeight: 'bold' }}>First Name</TableCell>
                            <TableCell style={{ color: 'blue', fontWeight: 'bold' }}>Last Name</TableCell>
                            <TableCell style={{ color: 'blue', fontWeight: 'bold' }}>Email</TableCell>
                            <TableCell style={{ color: 'blue', fontWeight: 'bold' }}>Phone</TableCell>
                            <TableCell style={{ color: 'blue', fontWeight: 'bold' }}>Company</TableCell>
                            <TableCell style={{ color: 'blue', fontWeight: 'bold' }}>Job Title</TableCell>
                            <TableCell style={{ color: 'blue', fontWeight: 'bold' }}>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {contacts.map((contact) => (
                            <TableRow key={contact._id}>
                                <TableCell>{contact.firstName}</TableCell>
                                <TableCell>{contact.lastName}</TableCell>
                                <TableCell>{contact.email}</TableCell>
                                <TableCell>{contact.phone}</TableCell>
                                <TableCell>{contact.company}</TableCell>
                                <TableCell>{contact.jobTitle}</TableCell>
                                <TableCell className="actions-cell">
                                    <Button className="edit-button" style={{ backgroundColor: 'green', color: 'white', margin:"5px" }} onClick={() => handleOpen(contact)}>Edit</Button>
                                    
                                    <Button className="delete-button" style={{ backgroundColor: 'red', color: 'white' }} onClick={() => onDelete(contact._id)}>Delete</Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>

            <Dialog open={open} onClose={handleClose} fullScreen={isMobile}>
                <DialogContent>
                    {["firstName", "lastName", "email", "phone", "company", "jobTitle"].map((field) => (
                        <TextField
                            key={field}
                            margin="dense"
                            label={field.split(/(?=[A-Z])/).join(" ")}
                            name={field}
                            value={currentContact[field] || ""}
                            onChange={handleChange}
                            fullWidth
                        />
                    ))}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose}>Cancel</Button>
                    <Button onClick={handleSave} color="primary">
                        Save
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
};

export default ContactsTable;
