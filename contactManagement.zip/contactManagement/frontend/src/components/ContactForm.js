import React, { useState } from "react";
import { TextField, Button, Grid, Box } from "@mui/material";

const ContactForm = ({ onSubmit }) => {
    const [formData, setFormData] = useState({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        company: "",
        jobTitle: "",
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(formData);
        setFormData({
            firstName: "",
            lastName: "",
            email: "",
            phone: "",
            company: "",
            jobTitle: "",
        });
    };

    return (
        <Box
            component="form"
            onSubmit={handleSubmit}
            sx={{
                p: 5,
                maxWidth: 900,
                mx: "auto",
                backgroundColor: "#f5f5f5",
                borderRadius: 2,
                boxShadow: "0px 4px 12px rgba(0, 0, 0, 0.1)",
            }}
        >
            <Grid container spacing={3}>
                {["firstName", "lastName", "email", "phone", "company", "jobTitle"].map((field) => (
                    <Grid item xs={12} sm={6} key={field}>
                        <TextField
                            fullWidth
                            label={field.split(/(?=[A-Z])/).join(" ")}
                            name={field}
                            value={formData[field]}
                            onChange={handleChange}
                            required
                            sx={{
                                backgroundColor: "#ffffff",
                                borderRadius: 1,
                            }}
                        />
            </Grid>
        ))}
        <Grid
    item
    xs={12}
    sx={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
    }}
>
    <Button
        type="submit"
        variant="contained"
        color="primary"
        sx={{
            mt: 2,
            py: 1.5,
            fontSize: "1rem",
            backgroundColor: "#1976d2",
            "&:hover": {
                backgroundColor: "blue",
            },
        }}
    >
        Add Contact
    </Button>
</Grid>

    </Grid>
</Box>

    );
};

export default ContactForm;
