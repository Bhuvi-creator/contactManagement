import React, { useState, useEffect } from "react";
import ContactForm from "./components/ContactForm";
import ContactsTable from "./components/ContactsTable";
import axios from "axios";
import './App.css';

const App = () => {
    const [contacts, setContacts] = useState([]);
    const BASE_URL = "http://localhost:5000/contacts";

    // Fetch contacts from backend
    useEffect(() => {
        axios
            .get(BASE_URL)
            .then((response) => {
                setContacts(response.data);
            })
            .catch((error) => console.error("Error fetching contacts:", error));
    }, []);

    // Add new contact
    const addContact = (contact) => {
        axios
            .post(BASE_URL, contact)
            .then((response) => {
                setContacts([...contacts, response.data]);
            })
            .catch((error) => console.error("Error adding contact:", error));
    };

    // Delete contact
    const deleteContact = (id) => {
        axios
            .delete(`${BASE_URL}/${id}`)
            .then(() => {
                setContacts(contacts.filter((contact) => contact._id !== id));
            })
            .catch((error) => console.error("Error deleting contact:", error));
    };

    // Edit contact
    const editContact = (updatedContact) => {
        axios
            .put(`${BASE_URL}/${updatedContact._id}`, updatedContact)
            .then((response) => {
                setContacts(
                    contacts.map((contact) =>
                        contact._id === updatedContact._id ? response.data : contact
                    )
                );
            })
            .catch((error) => console.error("Error updating contact:", error));
    };

    return (
        <div>
            <h1 class="heading">Contact Management</h1>
            <ContactForm onSubmit={addContact} />
            <ContactsTable contacts={contacts} onDelete={deleteContact} onEdit={editContact} />
        </div>
    );
};

export default App;
